#include "camera.h"
#include <cmath>
#include <iostream>

namespace raytracer
{
    Camera::Camera(pugi::xml_node node)
    {
        Position = Vector3f(node.child("Position"));
        Gaze = Vector3f(node.child("Gaze"));
        Up = Vector3f(node.child("Up"));
        NearPlane = Vector4f(node.child("NearPlane"));
        NearDistance = node.child("NearDistance").text().as_float();
        ImageResolution = Vector2i(node.child("ImageResolution"));
        ImageName = node.child("ImageName").text().as_string();

        Gaze.Normalize();
        Up.Normalize();
        w = Gaze * -1;
        u = Vector3f::Cross(Up, w).Normalized();
        v = Vector3f::Cross(w, u).Normalized();

        img_center = Position + Gaze * NearDistance;
        q = img_center + v * NearPlane.W + u * NearPlane.X;
    }

    Ray Camera::GetRay(int x, int y)
    {
        float su = (x + .5) * ((NearPlane.Y - NearPlane.X) / ImageResolution.X);
        float sv = (y + .5) * ((NearPlane.W - NearPlane.Z) / ImageResolution.Y);
        Vector3f s = q + (u * su) - (v * sv);
        return Ray(Position, (s - Position).Normalized());
    }

    std::ostream& operator<<(std::ostream& os, const Camera& cam)
    {
        os << "Position " << cam.Position << std::endl;
        os << "Gaze " << cam.Gaze << std::endl;
        os << "Up " << cam.Up << std::endl;
        os << "NearPlane " << cam.NearPlane << std::endl;
        os << "NearDistance " << cam.NearDistance << std::endl;                        
        os << "ImageResolution " << cam.ImageResolution << std::endl;                        
        os << "ImageName " << cam.ImageName << std::endl;  
        return os;                      
    }
}