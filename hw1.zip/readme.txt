Run Instructions:

-> make all
-> ./raytracer scene.xml threadNum(optional)

example:

-> ./raytracer input/simple.xml
# uses 1 thread

-> ./raytracer input/bunny.xml 32
# uses 32 thread